package com.taptocure.entities;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Document(collection="Appointments")
public class Appt {
	
	@Id
	private Integer apptId;
	private String doctorId;
	private Integer patientId;
	private String diseases;
	private String fullAddress;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date apptDate;
	private String apptTime;
	
	public Integer getApptId() {
		return apptId;
	}
	public void setApptId(Integer apptId) {
		this.apptId = apptId;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public Integer getPatientId() {
		return patientId;
	}
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}
	public String getDiseases() {
		return diseases;
	}
	public void setDiseases(String diseases) {
		this.diseases = diseases;
	}
	public String getFullAddress() {
		return fullAddress;
	}
	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}
	public Date getApptDate() {
		return apptDate;
	}
	public void setApptDate(Date apptDate) {
		this.apptDate = apptDate;
	}
	public String getApptTime() {
		return apptTime;
	}
	public void setApptTime(String apptTime) {
		this.apptTime = apptTime;
	}
	public Appt(Integer apptId, String doctorId, Integer patientId, String diseases, String fullAddress, Date apptDate,
			String apptTime) {
		super();
		this.apptId = apptId;
		this.doctorId = doctorId;
		this.patientId = patientId;
		this.diseases = diseases;
		this.fullAddress = fullAddress;
		this.apptDate = apptDate;
		this.apptTime = apptTime;
	}
	public Appt() {
		super();
	}
	@Override
	public String toString() {
		return "Appt [apptId=" + apptId + ", doctorId=" + doctorId + ", patientId=" + patientId + ", diseases="
				+ diseases + ", fullAddress=" + fullAddress + ", apptDate=" + apptDate + ", apptTime=" + apptTime + "]";
	}
	
	
	
}
