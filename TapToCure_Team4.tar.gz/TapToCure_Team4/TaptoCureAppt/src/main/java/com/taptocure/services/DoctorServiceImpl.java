package com.taptocure.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.taptocure.dao.DoctorDao;
import com.taptocure.entities.Doctor;


@Service
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	private DoctorDao doctorDao;

	public void addDoctor(Doctor d)
	{
		doctorDao.save(d);
	}

	@Override
	public List<Doctor> getAllDoctor()
	{
		return doctorDao.findAll();
	}


	@Override
	public Doctor getDoctorById(Integer doctorId) {
		Optional<Doctor> d = doctorDao.findById(doctorId);
		if (d.isPresent()) 
		{
			return d.get();
		}
		return null;
	}

	@Override
	public void deleteDoctor(Integer doctorId) 
	{
		doctorDao.deleteById(doctorId);
	}
	

	/*
	 * @Override public List<Doctor> searchBySpecialist(Integer doctorId) {
	 * System.out.println(doctorDao.custom(doctorId)); return
	 * doctorDao.custom(doctorId);
	 * 
	 * }
	 */
}
