package com.taptocure.services;

import java.util.Date;
import java.util.List;


import com.taptocure.entities.Patient;


public interface PatientService {
	
	public void addPatient(Patient p);
	public List<Patient> getAllPatient();
	public Patient getPatientById(Integer patientId);
	public void deletePatient(Integer patientId);
    
	}
