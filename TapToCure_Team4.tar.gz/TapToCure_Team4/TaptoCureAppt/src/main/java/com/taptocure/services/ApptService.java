package com.taptocure.services;

import java.util.Date;
import java.util.List;


import com.taptocure.entities.Appt;
import com.taptocure.entities.Doctor;


public interface ApptService {
	
public void addAppt(Appt a);
public List<Appt> getAllAppt();

}
