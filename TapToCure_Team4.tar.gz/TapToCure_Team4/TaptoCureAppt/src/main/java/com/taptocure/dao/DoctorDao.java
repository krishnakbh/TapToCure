package com.taptocure.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.taptocure.entities.Doctor;

@Repository
public interface DoctorDao extends MongoRepository<Doctor, Integer>{

//	@Query("{doctorId:?0}")
//	public List<Doctor> custom(Integer doctorId);
//	//Optional<Doctor> custom(Integer doctorId);
}
