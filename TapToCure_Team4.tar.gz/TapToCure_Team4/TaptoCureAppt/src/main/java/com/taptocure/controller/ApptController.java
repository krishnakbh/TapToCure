package com.taptocure.controller;

import java.util.Date;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.taptocure.dao.ApptDao;
import com.taptocure.entities.Appt;
import com.taptocure.entities.Doctor;
import com.taptocure.entities.Patient;
import com.taptocure.services.ApptService;
import com.taptocure.services.ApptServiceImpl;
import com.taptocure.services.DoctorService;
import com.taptocure.services.PatientService;

@Controller
public class ApptController {

	@Autowired
	private ApptService apptService;

	@Autowired
	private PatientService patientService;

	@Autowired
	private DoctorService doctorService;

	@GetMapping("/")
	public String home(Model m) {
		List<Patient> pat = patientService.getAllPatient();
		m.addAttribute("pat", pat);
		List<Doctor> doc = doctorService.getAllDoctor();
		m.addAttribute("doc", doc);
		return "patindex";
	}

	@GetMapping("/details/{patientId}")
	public String patientSearchById(@PathVariable int patientId, Model m) {
		Patient p = patientService.getPatientById(patientId);
		m.addAttribute("pat", p);
		return "details";
	}

	@GetMapping("/appointment/{patientId}")
	public String appointment(@PathVariable int patientId, Model m) {
		Patient p = patientService.getPatientById(patientId);
		m.addAttribute("pat", p);
		List<Doctor> doc = doctorService.getAllDoctor();
		m.addAttribute("doc", doc);
		m.addAttribute("doctor", new Doctor());
		return "appointment";
	}

	@PostMapping("/bookApptSuccess")
	public String bookAppt(@ModelAttribute Appt a, Model m) {
		System.out.println(a);
		apptService.addAppt(a);
		// List<Appt> appt= apptService.getAllAppt();
		// System.out.println(appt.get(0).getApptDate());
		// System.out.println(appt.get(0).getApptDate().getTime());
		// m.addAttribute("appt", appt);
		// redMsg.addFlashAttribute("msg", "Appointment Booked successfully..");
		return "bookApptSuccess";
	}

	@PostMapping("/patient")
	public String patientReg(@ModelAttribute Patient p, RedirectAttributes redMsg) {
		System.out.println(p);
		patientService.addPatient(p);
		redMsg.addFlashAttribute("msg", "Patient Registered successfully..");
		return "redirect:/";
	}

	@GetMapping("/appointmentlist")
	public String searchBySpecialist(Model m) {
		List<Appt> appt = apptService.getAllAppt();
		m.addAttribute("appt", appt);
		return "appointmentlist";
	}

	@GetMapping("/appointment/{patientId}/bookAppt2")
	public String bookApptSuccess(@ModelAttribute Appt a, Model m, RedirectAttributes redMsg) {
		redMsg.addFlashAttribute("msg", "Appointment Booked successfully..");
		return "bookApptSuccess2";
	}

}
