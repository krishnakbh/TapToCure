package com.taptocure.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.taptocure.dao.ApptDao;
import com.taptocure.entities.Appt;
import com.taptocure.entities.Doctor;


@Service
public class ApptServiceImpl implements ApptService {
	@Autowired
	private ApptDao apptDao;

	@Override
	public void addAppt(Appt a) {
	apptDao.save(a);
	}

	@Override
	public List<Appt> getAllAppt() {
	return apptDao.findAll();
		
	}

}
