package com.taptocure.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.taptocure.entities.Patient;

public interface PatientDao extends MongoRepository<Patient, Integer> {

}
