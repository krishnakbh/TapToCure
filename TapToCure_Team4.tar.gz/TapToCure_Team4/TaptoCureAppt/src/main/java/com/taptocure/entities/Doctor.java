package com.taptocure.entities;


import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



@Document(collection="Doctors")
public class Doctor {
	
	@Id
	private Integer doctorId;
	private String doctorName;
	private String gender;
	private Integer  age;
	private Long phNo;
	private String email;
	private String location;;
	private Long fee;
	private String specialist;
	
	public Integer getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getSpecialist() {
		return specialist;
	}
	public void setSpecialist(String specialist) {
		this.specialist = specialist;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Long getPhNo() {
		return phNo;
	}
	public void setPhNo(Long phNo) {
		this.phNo = phNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getFee() {
		return fee;
	}
	public void setFee(Long fee) {
		this.fee = fee;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Doctor(Integer doctorId, String doctorName, String specialist, String gender, Long phNo, String email,
			Long fee, String location, Integer age) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.specialist = specialist;
		this.gender = gender;
		this.phNo = phNo;
		this.email = email;
		this.fee = fee;
		this.location = location;
		this.age = age;
	}
	public Doctor() {
		super();
	}
	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", specialist=" + specialist
				+ ", gender=" + gender + ", phNo=" + phNo + ", email=" + email + ", fee=" + fee + ", location="
				+ location + ", age=" + age + "]";
	}
	
	
	
	
}
