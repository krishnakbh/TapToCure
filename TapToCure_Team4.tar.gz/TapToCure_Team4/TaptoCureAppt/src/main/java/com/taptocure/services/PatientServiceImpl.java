package com.taptocure.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.taptocure.dao.PatientDao;


import com.taptocure.entities.Patient;

@Service
public class PatientServiceImpl implements PatientService {
	
	@Autowired
	private PatientDao patientDao;
	
	public void addPatient(Patient p)
	{
		patientDao.save(p);
		System.out.println(p);
	}

	@Override
	public List<Patient> getAllPatient() {
		return patientDao.findAll();
	}

	@Override
	public Patient getPatientById(Integer patientId) {
		Optional<Patient> p= patientDao.findById(patientId);
		if(p.isPresent()) {
			return p.get();
		}
		return null;
	}

	@Override
	public void deletePatient(Integer patientId) {
		patientDao.deleteById(patientId);
		
	}

	

	


	
	
	
	

	

	
	

	
	

	


	
	
	
	

}
