package com.taptocure.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.taptocure.dao.DoctorDao;
import com.taptocure.entities.Doctor;
import com.taptocure.services.DoctorService;
import com.taptocure.services.DoctorServiceImpl;

//import jakarta.servlet.http.HttpSession;

@Controller
public class DoctorController {

	@Autowired
	private DoctorService doctorService;
	
	// Project  home page
	@GetMapping("/")
	public String home(Model m) {
		return "home";
	}

	// Get All Doctors list with Edit and Delete options
	@GetMapping("/index")
	public String home2(Model m) {
		List<Doctor> doc = doctorService.getAllDoctor();
		m.addAttribute("doc", doc);
		return "index";
	}
	
	//Get all doctors list
	@GetMapping("/doctordetails")
	public String doctorDetails(Model m) {
		List<Doctor> doc = doctorService.getAllDoctor();
		m.addAttribute("doc", doc);
		return "doctordetails";
	}

	//Add doctors to the List
	@GetMapping("/adddoctor")
	public String addDocfrm(Model m) {
		List<String> specialist = Arrays.asList("Dentist", "Dermatology", "Cardiologist", "Pediatrics", "ENT",
				"General Surgery");
		m.addAttribute("lspecialist", specialist);
		m.addAttribute("d", new Doctor());
		return "add_doctor";
	}

	// Get Specialist by Dermatology
	@GetMapping("/specialist")
	public String searchBySpecialist(Model m) {
		List<Doctor> doc = this.doctorService.searchBySpecialist("Dermatology");
		m.addAttribute("doc", doc);
		return "specialist";
	}

	// Get Specialist by Dentist
	@GetMapping("/specialist2")
	public String searchBySpecialist2(Model m) {
		List<Doctor> doc = this.doctorService.searchBySpecialist("Dentist");
		m.addAttribute("doc", doc);
		return "specialist2";
	}

	// Get Specialist by ENT
	@GetMapping("/specialist3")
	public String searchBySpecialist3(Model m) {
		List<Doctor> doc = this.doctorService.searchBySpecialist("ENT");
		m.addAttribute("doc", doc);
		return "specialist3";
	}
	
	//Add doctor and redirect to Index Page & show Flash Message
	@PostMapping("/doctor")
	public String doctorReg(@ModelAttribute Doctor d1, RedirectAttributes redMsg) {
		doctorService.addDoctor(d1);
		redMsg.addFlashAttribute("msg", "Doctor Registered successfully..");
		return "redirect:/doctordetails";
	}

	// Edit Doctors details
	@GetMapping("/edit/{doctorId}")
	public String edit(@PathVariable Integer doctorId, Model m) {
		Doctor d = doctorService.getDoctorById(doctorId);
		m.addAttribute("doc", d);
		return "edit";
	}

	//Update Doctors details
	@PostMapping("/update")
	public String updateDoctor(@ModelAttribute Doctor d, RedirectAttributes redMsg) {
		doctorService.addDoctor(d);
		redMsg.addFlashAttribute("msg", "Doctor details are updated successfully..");
		return "redirect:/doctordetails";
	}

	//Delete Doctors details
	@GetMapping("/delete/{doctorId}")
	public String deleteDoctor(@PathVariable Integer doctorId, RedirectAttributes redMsg) {
		doctorService.deleteDoctor(doctorId);
		redMsg.addFlashAttribute("msg", "Doctor details are deleted successfully..");
		return "redirect:/index";
	}

	//Details of Particular doctor
	@GetMapping("/details/{doctorId}")
	public String doctorDetails(@PathVariable Integer doctorId, Model m) {
		Doctor d = doctorService.getDoctorById(doctorId);
		m.addAttribute("doc", d);
		return "details";
	}
	
}
