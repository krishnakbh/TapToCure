package com.taptocure.services;

import java.util.Date;
import java.util.List;


import com.taptocure.entities.Doctor;


public interface DoctorService {
	public void addDoctor(Doctor d);
	public List<Doctor> getAllDoctor();
	public Doctor getDoctorById(Integer doctorId);
	public void deleteDoctor(Integer doctorId);
	public List<Doctor> searchBySpecialist(String specialist);
	}
