package com.taptocure.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.taptocure.dao.DoctorDao;
import com.taptocure.entities.Doctor;

@Service
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	private DoctorDao doctorDao;

//Adding the Doctor Details
	public void addDoctor(Doctor d) {
		doctorDao.save(d);
	}

	// Fetching the Doctor Details
	@Override
	public List<Doctor> getAllDoctor() {
		return doctorDao.findAll();
	}

//Fetching the Doctor Details by PatientId
	@Override
	public Doctor getDoctorById(Integer doctorId) {
		Optional<Doctor> d = doctorDao.findById(doctorId);
		if (d.isPresent()) {
			return d.get();
		}
		return null;
	}

	// Deleting the Doctor Details
	@Override
	public void deleteDoctor(Integer doctorId) {
		doctorDao.deleteById(doctorId);
	}

	// Fetching the Doctor Details by Specialist
	@Override
	public List<Doctor> searchBySpecialist(String specialist) {

		List<Doctor> ls = this.doctorDao.findAll();
		ls = ls.stream().filter(q -> ((String) q.getSpecialist()).equals(specialist)).toList();
		System.out.println(ls);
		return ls;

	}

}
