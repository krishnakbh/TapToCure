package com.taptocure.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.taptocure.dao.PatientDao;
import com.taptocure.entities.Patient;
import com.taptocure.services.PatientService;
import com.taptocure.services.PatientServiceImpl;

@Controller
public class PatientController {
	@Autowired
	private PatientService patientService;
	
	// Home Page
	  @GetMapping("/") 
	  public String home(Model m) 
	  { 
		  List<Patient> pat= patientService.getAllPatient();
		  m.addAttribute("pat", pat);
		  return "index";
	  }
	  		
	// Adding the Patient
	@GetMapping("/addpatient")
	public String addPatfrm() {
		return "add_patient";
	}
	
	// Adding the Patient
	@PostMapping("/patient")
	public String patientReg(@ModelAttribute Patient p, RedirectAttributes redMsg) {
	System.out.println(p);
	patientService.addPatient(p);
	redMsg.addFlashAttribute("msg", "Patient Registered successfully..");
		return "redirect:/";
	
		}
	
	// Fetching  the Patient Details for update
	@GetMapping("/edit/{patientId}")
	public String edit(@PathVariable int patientId, Model m) {
		Patient p = patientService.getPatientById(patientId);
		m.addAttribute("pat", p);
		return "edit";
	}
	
	// Updating the Patient Details
	@PostMapping("/update")
	public String updatePatient(@ModelAttribute Patient p,RedirectAttributes redMsg) {
		patientService.addPatient(p);
		 redMsg.addFlashAttribute("msg", "Patient details are updated successfully..");
		return "redirect:/";
	}
	
	// Deleting the Patient Details
	@GetMapping("delete/{patientId}")
	public String deletePatient(@PathVariable int patientId,RedirectAttributes redMsg) {
		patientService.deletePatient(patientId);
		 redMsg.addFlashAttribute("msg", "Patient details are deleted successfully..");
		return "redirect:/";
	}

	@GetMapping("/details/{patientId}")
	public String patientSearchById(@PathVariable int patientId, Model m) {
		Patient p = patientService.getPatientById(patientId);
		m.addAttribute("pat", p);
		return "details";
	}
	
	// Getting appointment details
	@GetMapping("/appointment/{patientId}")
	public String appointment(@PathVariable int patientId, Model m) {
		Patient p = patientService.getPatientById(patientId);
		m.addAttribute("pat", p);
		return "appointment";
	}
}
