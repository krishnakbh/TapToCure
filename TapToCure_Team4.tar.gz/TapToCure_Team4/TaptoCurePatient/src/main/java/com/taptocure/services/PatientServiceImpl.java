package com.taptocure.services;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.taptocure.dao.PatientDao;


import com.taptocure.entities.Patient;

@Service
public class PatientServiceImpl implements PatientService {
	
	@Autowired
	private PatientDao patientDao;
	
	// saving the Patient Details
	public void addPatient(Patient p)
	{
		patientDao.save(p);
	}

	//Getting the Patient Details
	@Override
	public List<Patient> getAllPatient() {
		return patientDao.findAll();
	}

	// fetching the Patient Details by PatientId
	@Override
	public Patient getPatientById(Integer patientId) {
		Optional<Patient> p= patientDao.findById(patientId);
		if(p.isPresent()) {
			return p.get();
		}
		return null;
	}
	
	//Deleting the Patient Details
	@Override
	public void deletePatient(Integer patientId) {
		patientDao.deleteById(patientId);
		
	}

	

	


	
	
	
	

	

	
	

	
	

	


	
	
	
	

}
